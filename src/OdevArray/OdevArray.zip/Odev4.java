package OdevArray;

public class Odev4 {
    public static void main(String[] args) {
//        Array oluşturun.
//        elemanları : 13, 15,14,16,16
//        Arrayin elemanlarını yazdırın.

        int[] sayi = new int[]{13, 15, 14, 16, 16,};
        int eleman=0;
        for (int i = 0; i <sayi.length ; i++) {
        eleman++;    
            
        }
        System.out.println("eleman = " + eleman);
    }


}
