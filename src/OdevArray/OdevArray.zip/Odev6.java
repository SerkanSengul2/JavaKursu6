package OdevArray;

public class Odev6 {
    public static void main(String[] args) {
//        String Array (Dizi) oluşturunuz.
//                elemanları :Apple, Orange, Babana, Kiwi
//        Array 'leri tüm elemanları yazdırınız.


        String dizi[] = new String[]{"Apple", "Orange", "Babana", "Kiwi"};
        
        for (int i = 0; i < dizi.length ; i++) {
            System.out.println("elman= "+dizi[i]);
        }

    }


}
