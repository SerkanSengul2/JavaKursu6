package OOPodev1;

public class OGR {


    String adi;
    int okulno;
    int notu;
//tasarı aşaması
}

